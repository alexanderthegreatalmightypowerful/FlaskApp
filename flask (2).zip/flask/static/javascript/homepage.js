//button route functions


function go_to_game_page(){
    window.location.href = '404';
}

function go_to_statistics_page(){
    window.location.href = 'statistics';
}

function go_to_personal_statistics_page(){
    window.location.href = 'personal_statistics';
}

function go_to_home_page(){
    window.location.href = 'home';   
}

function signed_in(value){
    console.log(value);
}

function sign_in_page(){
    //alert("WINDOW OPENING");
    window.location.href = 'sign_in_page';
}

function go_to_create_account_page(){
    window.location.href = 'create_account';
}